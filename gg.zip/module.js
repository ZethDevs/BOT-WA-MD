module.exports = {
modul: {
    yt: require('youtube-yts'),
    ytdl: require('ytdl-core')
}
}